#!/usr/bin/env python3

import sys

if len(sys.argv) != 2:
    print("missing argument: file name")
    exit(1)

with open(sys.argv[1], "r+") as f:
    data = f.read()
    f.truncate(0)

if len(data) > 0:
    print(data, end="")
